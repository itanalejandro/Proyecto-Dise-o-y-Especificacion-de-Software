using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;
using System.Windows.Media;
using System.Windows.Media.Effects;
using System.Windows.Data;
using System.Windows.Input;
using System.ComponentModel;

namespace Ftracker.Desktop;

internal enum ThemePalette { Azul, Fime }

internal static class ThemeManager
{
    private static readonly Dictionary<string, SolidColorBrush> brushes = [];
    private static readonly Dictionary<string, ThemeColor> values = [];
    private sealed class ThemeColor : INotifyPropertyChanged
    {
        private Color color;
        public Color Color { get => color; set { color = value; PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(nameof(Color))); } }
        public event PropertyChangedEventHandler? PropertyChanged;
    }

    // Cada color tiene dos valores: [claro, oscuro].
    private static readonly Dictionary<string, string[]> Common = new()
    {
        ["Danger"] = ["#B3261E", "#FFAAA2"], ["DangerBorder"] = ["#E7B4B0", "#975E5A"]
    };
    // Paleta azul original de Ftracker.
    private static readonly Dictionary<string, string[]> Azul = new()
    {
        ["Page"] = ["#F3F6FA", "#151C25"], ["Surface"] = ["#FFFFFF", "#202B38"],
        ["Text"] = ["#20354A", "#E5EDF5"], ["Muted"] = ["#52677D", "#AFBDCC"],
        ["Accent"] = ["#245F9D", "#315F92"], ["Link"] = ["#245F9D", "#9ACBFF"],
        ["Border"] = ["#C8D6E5", "#45566A"], ["Header"] = ["#EDF3F9", "#2B394A"],
        ["Alternate"] = ["#F8FAFD", "#253141"], ["Selected"] = ["#E7F0FB", "#304D6D"]
    };
    // Paleta FIME UANL: verde y blanco, los colores con los que se identifica la Facultad.
    private static readonly Dictionary<string, string[]> Fime = new()
    {
        ["Page"] = ["#F2F7F3", "#121A15"], ["Surface"] = ["#FFFFFF", "#1B2720"],
        ["Text"] = ["#1F3A2A", "#E4F0E7"], ["Muted"] = ["#526B5B", "#A9BDB0"],
        ["Accent"] = ["#1B7A43", "#2E7D4F"], ["Link"] = ["#17703B", "#7FD39A"],
        ["Border"] = ["#C6DACB", "#3F5648"], ["Header"] = ["#E8F2EA", "#263529"],
        ["Alternate"] = ["#F7FAF7", "#213026"], ["Selected"] = ["#DFF0E3", "#2D4A38"]
    };

    private static string PreferencePath => Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Ftracker", "tema.txt");
    public static bool IsDark { get; private set; }
    public static ThemePalette Palette { get; private set; }

    public static Brush Get(string key)
    {
        if (!brushes.TryGetValue(key, out var brush))
        {
            values[key] = new ThemeColor();
            brushes[key] = brush = new SolidColorBrush();
            BindingOperations.SetBinding(brush, SolidColorBrush.ColorProperty, new Binding(nameof(ThemeColor.Color)) { Source = values[key] });
        }
        return brush;
    }

    public static void Initialize()
    {
        var dark = false; var palette = ThemePalette.Azul;
        try
        {
            // Formato: "claro", "oscuro" (versiones anteriores) o "oscuro;fime".
            var parts = File.ReadAllText(PreferencePath).Trim().Split(';');
            dark = parts[0] == "oscuro";
            if (parts.Length > 1 && parts[1] == "fime") palette = ThemePalette.Fime;
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
        Apply(dark, palette);
    }

    public static void Apply(bool dark, ThemePalette palette)
    {
        IsDark = dark; Palette = palette;
        var resources = System.Windows.Application.Current.Resources;
        var index = dark ? 1 : 0;
        foreach (var colors in new[] { Common, palette == ThemePalette.Fime ? Fime : Azul })
            foreach (var (key, pair) in colors)
            {
                var brush = (SolidColorBrush)Get(key);
                values[key].Color = (Color)ColorConverter.ConvertFromString(pair[index]);
                resources[key] = brush;
            }
        resources[SystemColors.WindowBrushKey] = Get("Surface");
        resources[SystemColors.WindowTextBrushKey] = Get("Text");
        resources[SystemColors.ControlBrushKey] = Get("Header");
        resources[SystemColors.ControlTextBrushKey] = Get("Text");
        resources[SystemColors.GrayTextBrushKey] = Get("Muted");
        resources[SystemColors.InactiveSelectionHighlightBrushKey] = Get("Selected");
        resources[SystemColors.InactiveSelectionHighlightTextBrushKey] = Get("Text");
        if (palette == ThemePalette.Fime)
        {
            // La fila seleccionada de las tablas usa el color del sistema (azul de Windows); en FIME se cambia a verde.
            resources[SystemColors.HighlightBrushKey] = Get("Accent");
            resources[SystemColors.HighlightTextBrushKey] = Brushes.White;
        }
        else
        {
            resources.Remove(SystemColors.HighlightBrushKey);
            resources.Remove(SystemColors.HighlightTextBrushKey);
        }
    }

    private static void Save()
    {
        try
        {
            Directory.CreateDirectory(Path.GetDirectoryName(PreferencePath)!);
            File.WriteAllText(PreferencePath, (IsDark ? "oscuro" : "claro") + ";" + (Palette == ThemePalette.Fime ? "fime" : "azul"));
        }
        catch (IOException) { }
        catch (UnauthorizedAccessException) { }
    }

    /// <summary>Botón "Tema" que abre un menú con el modo claro/oscuro y la paleta de colores.</summary>
    public static FrameworkElement ThemeMenu(bool persist = true)
    {
        var host = new Grid { VerticalAlignment = VerticalAlignment.Center };
        var button = new Button { Content = "Tema ▾", Style = (Style)System.Windows.Application.Current.FindResource("SecondaryButton"), ToolTip = "Cambiar el tema de la interfaz" };
        System.Windows.Automation.AutomationProperties.SetName(button, "Tema");
        var popup = new Popup { PlacementTarget = button, Placement = PlacementMode.Bottom, StaysOpen = false, AllowsTransparency = true, PopupAnimation = PopupAnimation.Fade, HorizontalOffset = 0, VerticalOffset = 2 };

        var panel = new StackPanel { Width = 244 };
        panel.Children.Add(SectionLabel("Modo"));
        var modeSwitch = new Button { Style = (Style)System.Windows.Application.Current.FindResource("ThemeSwitch"), HorizontalAlignment = HorizontalAlignment.Left, Margin = new Thickness(0, 4, 0, 14) };
        panel.Children.Add(modeSwitch);
        panel.Children.Add(SectionLabel("Colores de la interfaz"));
        var options = new List<(Button Button, ThemePalette Palette)>();
        foreach (var (palette, label, c1, c2) in new[] { (ThemePalette.Azul, "Azul", "#245F9D", "#9ACBFF"), (ThemePalette.Fime, "FIME UANL", "#1B7A43", "#7FD39A") })
        {
            var option = PaletteOption(label, c1, c2);
            option.Click += (_, _) => { Apply(IsDark, palette); Describe(); if (persist) Save(); };
            options.Add((option, palette)); panel.Children.Add(option);
        }

        void Describe()
        {
            modeSwitch.Content = IsDark ? "Oscuro" : "Claro";
            modeSwitch.Tag = IsDark ? "Oscuro" : "Claro";
            modeSwitch.ToolTip = IsDark ? "Cambiar a modo claro" : "Cambiar a modo oscuro";
            System.Windows.Automation.AutomationProperties.SetName(modeSwitch, (string)modeSwitch.ToolTip);
            foreach (var (option, palette) in options)
            {
                var selected = palette == Palette;
                option.Background = selected ? Get("Selected") : Get("Surface");
                option.BorderBrush = selected ? Get("Link") : Get("Border");
                option.BorderThickness = new Thickness(selected ? 2 : 1);
                System.Windows.Automation.AutomationProperties.SetName(option, (palette == ThemePalette.Fime ? "Colores FIME UANL" : "Colores azules") + (selected ? ", seleccionado" : ""));
                if (option.Content is StackPanel row && row.Children[^1] is TextBlock check) check.Visibility = selected ? Visibility.Visible : Visibility.Hidden;
            }
        }
        modeSwitch.Click += (_, _) => { Apply(!IsDark, Palette); Describe(); if (persist) Save(); };
        Describe();

        var frame = new Border
        {
            Background = Get("Surface"), BorderBrush = Get("Border"), BorderThickness = new Thickness(1), CornerRadius = new CornerRadius(10),
            Padding = new Thickness(14), Margin = new Thickness(10), Child = panel,
            Effect = new DropShadowEffect { BlurRadius = 12, ShadowDepth = 2, Opacity = 0.28, Color = Colors.Black }
        };
        frame.KeyDown += (_, e) => { if (e.Key == Key.Escape) { popup.IsOpen = false; button.Focus(); e.Handled = true; } };
        popup.Child = frame;

        // Evita que el mismo clic que cierra el menú lo vuelva a abrir.
        var closedAt = DateTime.MinValue;
        popup.Closed += (_, _) => closedAt = DateTime.UtcNow;
        popup.Opened += (_, _) => modeSwitch.Focus();
        button.Click += (_, _) => { if (!popup.IsOpen && DateTime.UtcNow - closedAt > TimeSpan.FromMilliseconds(250)) popup.IsOpen = true; };

        host.Children.Add(button); host.Children.Add(popup);
        return host;
    }

    private static TextBlock SectionLabel(string text) => new() { Text = text, FontSize = 12, FontWeight = FontWeights.SemiBold, Foreground = Get("Muted") };

    private static Button PaletteOption(string label, string color1, string color2)
    {
        System.Windows.Shapes.Ellipse Swatch(string color, double overlap) => new() { Width = 16, Height = 16, Fill = (Brush)new BrushConverter().ConvertFromString(color)!, Stroke = Get("Border"), StrokeThickness = 1, Margin = new Thickness(overlap, 0, 0, 0) };
        var row = new StackPanel { Orientation = Orientation.Horizontal };
        row.Children.Add(Swatch(color1, 0)); row.Children.Add(Swatch(color2, -5));
        row.Children.Add(new TextBlock { Text = label, Margin = new Thickness(10, 0, 10, 0), VerticalAlignment = VerticalAlignment.Center, Foreground = Get("Text") });
        row.Children.Add(new TextBlock { Text = "✓", Foreground = Get("Link"), FontWeight = FontWeights.Bold, VerticalAlignment = VerticalAlignment.Center });
        return new Button { Content = row, Style = (Style)System.Windows.Application.Current.FindResource("SecondaryButton"), Margin = new Thickness(0, 4, 0, 0), Padding = new Thickness(12, 8, 12, 8) };
    }
}
